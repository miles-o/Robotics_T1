#include <stdio.h>


void timestables() {
  int base;
  int current;
  int end;
  int ans;
  printf("base: ");
  scanf(" %d", &base);
  printf("start: ");
  scanf(" %d", &current);
  printf("end: ");
  scanf(" %d", &end);
  while(current <= end) {
    ans = base * current;
    printf("%d * %d = %d\n", base, current, ans);
    current = current + 1;
  }
}

void whileloops() {
  char shape  = '*';
  int height = 1;
  int length = 1;
  while (height <= 4) {
    while (length <= height) {
        printf("%c", shape);
        length = length + 1;
      }
      printf("\n");
      height = height + 1;
      length = 1;
  }
  length = 1;
  height = 1;
  printf("\n\n\n");

  while (height <= 3) {
    while (length <= 2 * height - 1) {
        printf("%c", shape);
        length = length + 1;
      }
      printf("\n");
      height = height + 1;
      length = 1;
  }
  height = height - 2;
  while (height >= 1) {
      while (length <= 2 * height - 1) {
          printf("%c", shape);
          length = length + 1;
        }
        printf("\n");
        height = height - 1;
        length = 1;
  }
}

void factorials() {
  int temp;
  int factorial = 1;
  int factorialbase;
  printf("Pick a number to print your factorial: ");
  scanf("%d", &factorialbase);
  temp = factorialbase;
  for (temp = temp; temp>1; temp--) {
    factorial = temp * factorial;
  }
  printf("%d! = %d", factorialbase, factorial);
}

void averages() {
  int temp;
  int numbers;
  int number;
  char userInput;
  char playing = 'y';
  while (playing == 'y'){
      temp = number;
      printf("Add a number to add to the sum: ");
      scanf("%d", &number);
      number = number + temp;
      printf("More numbers? y/n ");
      scanf(" %c", &userInput);
      numbers = numbers + 1;
      playing = userInput;
  }
  printf("%f", (double)number/(double)numbers);

}

int main(void) {
  int program = 1;
  printf("Choose program:\npress 1 for the times table\npress 2 for abusing wile loops\npress 3 for factorials\npress 4 for averages\n");
  scanf("%d", &program);
  printf("\n\n");
  if (program==1) {
  timestables();
  } else if (program==2) {
    whileloops();
  } else if (program==3) {
    factorials();
  } else if (program==4) {
    averages();
  }
}
#include <stdio.h>
#include <time.h>

void hensroosters() {
  int hens = 25+30/6;
  int roosters = 100-25*3;
  printf("I will now count my chickens\n");
  printf("I have %d hens and %d roosters", hens, roosters);
}
void carpool() {
  int cars = 100;
  int SpaceInCars = 4;
  int drivers = 30;
  int passengers = 90;
  printf("cars left over: %d\n", cars - drivers);
  printf("max car pool capacity: %d\n", drivers * SpaceInCars);
  printf("avg passengers per car: %d\n", passengers / drivers);
}
void calenderwonderland() {
  char name[20];
  int monthLength[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  char *nameinput = name;
  int daysold, monthsold, yearsold, days, months, year;
  scanf("%s", name);
  printf("name: %s\n", nameinput);
  printf("enter birthday in format dd mm yyyy: ");
  scanf("%d %d %d", &days, &months, &year);
  printf("%d %d %d\n", days, months, year);
  time_t t;
  time(&t);
  struct tm tm = *localtime(&t);
  yearsold = tm.tm_year+1899 - year;
  monthsold = tm.tm_mon+12 - months;
  daysold = yearsold * 365 + monthsold * 30;
  printf("%d\n", monthsold);
  printf("%d\n", yearsold);
  printf("%d\n", daysold);
  printf("%s", ctime(&t));
}


int main(void) {
  int program;
  printf("Choose program to run:\npress 1 for Hens and roosters \npress 2 for Carpool\npress 3 for Calender wonderland\n");
  scanf("%d", &program);
  if (program==1) {
    printf("Running Hens and Roosters\n\n");
    hensroosters();
  } else if (program==2){
    printf("Running Carpool\n\n");
    carpool();
  }  else if (program==3){
    printf("Running Calender wonderland\n\n");
    calenderwonderland();
  } else {
    printf("Invalid Program");
  }
  return 0;
}
#include <stdio.h>
#include <string.h>

void problem1() {
  int arrchar;
  int arrnum = 0;
  int element[10];
  printf("input 10 number of elements in the array\n");
  for (int i = 0; i < 10; i++) {
    printf("element - %d : ", i);
    scanf("%d", &arrchar);
    element[i] = arrchar;
  }
  for (int i = 0; i < 10; i++) {
    printf("%d ", element[i]);
  }
}

void problem2() {
  int arrlength, arrchar;
  int arrnum = 0;
  printf("Input number of elements to store in the array: ");
  scanf("%d", &arrlength);
  int element[arrlength];
  printf("input %d number of elements in the array\n", arrlength);
  for (int i = 0; i < arrlength; i++) {
    printf("element - %d : ", i);
    scanf("%d", &arrchar);
    element[i] = arrchar;
  }
  printf("The elements are\n");
  for (int i = 0; i < arrlength; i++) {
    printf("%d ", element[i]);
  }
  printf("\nIn reverse\n");
  for (int i = arrlength-1; i >= 0; i--) {
  printf("%d ", element[i]);
  }
}

void problem3() {
  int arrlength, arrchar, sum;
  int arrnum = 0;
  printf("Input number of elements to store in the array: ");
  scanf("%d", &arrlength);
  int element[arrlength];
  printf("input %d number of elements in the array\n", arrlength);
  for (int i = 0; i < arrlength; i++) {
    printf("element - %d : ", i);
    scanf("%d", &arrchar);
    element[i] = arrchar;
  }
  for (int i = 0; i < arrlength; i++) {
    sum = sum + element[i];
  }
  printf("sum of all elements is: %d ", sum);
}

void problem4() {
  int arrlength, arrchar;
  int arrnum = 0;
  printf("Input number of elements to store in the array: ");
  scanf("%d", &arrlength);
  int element[arrlength];
  printf("input %d number of elements in the array\n", arrlength);
  for (int i = 0; i < arrlength; i++) {
    printf("element - %d : ", i);
    scanf("%d", &arrchar);
    element[i] = arrchar;
  }
  int arr2length = sizeof(element)/4;
  int element2[arr2length];
  for (int i = 0; i < arr2length; i++) {
    element2[i] = element[i];
  }
  printf("The values in the array are\n");
  for (int i = 0; i < arrlength; i++) {
    printf("%d ", element[i]);
  }
  printf("\nThe values copied into the second array are\n");
  for (int i = 0; i < arr2length; i++) {
    printf("%d ", element2[i]);
  }
}

int main(void) {
  int program;
  printf("choose program:\npress 1 for store elements and print\npress 2 for read n values and reverse\npress 3 to sum up all elements\npress 4 to copy to another array\n");
  scanf(" %d", &program);
  if (program==1) {
    problem1();
  } else if (program==2) {
    problem2();
  } else if (program==3) {
    problem3();
  } else if (program==4) {
    problem4();
  }
}
#include <stdio.h>

void myAdd(int a, int b, int *ans) {
  *ans = a + b;
}

void mySubtract(int a, int b, int *ans) {
  *ans = a - b;
}

void myMultiply(int a, int b, int *ans) {
  *ans = a * b;
}

void myDivide(int a, int b, int *ans) {
  *ans = a / b;
}

void pcalc() {
  int i;
  for (i = 1; 1 < 2;) {
    int a;
    char o;
    int b;
    int ans;
    printf("enter equation:");
    scanf("%d %c %d", &a, &o, &b);
    if (o=='+') {
      myAdd(a, b, &ans);
    } else if (o=='-') {
      mySubtract(a, b, &ans);
    } else if (o=='*') {
      myMultiply(a, b, &ans);
    } else if (o=='/') {
      myDivide(a, b, &ans);
    }
    printf("%d\n", ans);
  }
}

void swap(int *a, int *b, int *c) {
  *c = *a;
  *a = *b;
  *b = *c;
}

int swapnums(int a, int b) {
  int c;
  
}

void pswap() {
  int a, b, c;
  printf("Input two numbers to swap: ");
  scanf("%d %d", &a, &b);
  swap(&a, &b, &c);
  printf("\nnum 1: %d \nnum 2: %d", a, b);
}

int main(void) {
  int program;
  printf("choose program:\npress 1 for calculator\npress 2 for swap\n");
  scanf("%d", &program);
  if (program==1) {
    printf("running calculator\n\n");
    pcalc();
  } else if (program==2) {
    printf("running swap\n\n");
    pswap();
  }
}